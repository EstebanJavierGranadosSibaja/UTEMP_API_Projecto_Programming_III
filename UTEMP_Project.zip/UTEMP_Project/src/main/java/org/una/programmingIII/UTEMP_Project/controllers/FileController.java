package org.una.programmingIII.UTEMP_Project.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.una.programmingIII.UTEMP_Project.dtos.FileMetadatumDTO;
import org.una.programmingIII.UTEMP_Project.exceptions.ResourceNotFoundException;
import org.una.programmingIII.UTEMP_Project.services.file.FileService;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/utemp/files")
public class FileController {

    private final FileService fileService;
    private static final Logger logger = LoggerFactory.getLogger(FileController.class);

    public FileController(FileService fileService) {
        this.fileService = fileService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<FileMetadatumDTO> getFileMetadata(@PathVariable Long id) {
        logger.info("Iniciando la obtención de metadatos para el archivo con ID: {}", id);
        return fileService.getFileMetadatumById(id)
                .map(fileMetadata -> {
                    logger.info("Metadatos del archivo con ID: {} encontrados exitosamente", id);
                    return ResponseEntity.ok(fileMetadata);
                })
                .orElseGet(() -> {
                    logger.warn("Archivo con ID: {} no encontrado", id);
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
                });
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFileChunk(@RequestBody FileMetadatumDTO fileChunkDTO) {
        logger.info("Recibiendo fragmento de archivo: {}", fileChunkDTO);

        // Validación detallada de los datos de archivo
        if (fileChunkDTO == null || fileChunkDTO.getFileName() == null || fileChunkDTO.getFileSize() <= 0) {
            logger.warn("Datos de archivo incompletos o inválidos: {}", fileChunkDTO);
            return ResponseEntity.badRequest().body("Datos de archivo incompletos o inválidos");
        }

        try {
            fileService.receiveFileChunk(fileChunkDTO);
            logger.info("Fragmento de archivo subido exitosamente: {}", fileChunkDTO);
            return ResponseEntity.ok("Fragmento de archivo subido exitosamente.");
        } catch (IOException e) {
            logger.error("Error al subir el fragmento de archivo: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al subir el fragmento de archivo");
        }
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<List<FileMetadatumDTO>> downloadFile(@PathVariable Long id) {
        logger.info("Iniciando la descarga del archivo con ID: {}", id);
        try {
            List<FileMetadatumDTO> fileChunks = fileService.downloadFileInChunks(id);

            if (fileChunks.isEmpty()) {
                logger.warn("Archivo con ID: {} no tiene fragmentos disponibles para descargar", id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(List.of());
            } else {
                logger.info("Fragmentos de archivo con ID: {} descargados exitosamente", id);
                return ResponseEntity.ok(fileChunks);
            }
        } catch (IOException e) {
            logger.error("Error al descargar el archivo con ID: {}", id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(List.of());
        }
    }

    @PutMapping
    public ResponseEntity<FileMetadatumDTO> updateFile(@RequestBody FileMetadatumDTO fileChunkDTO) {
        logger.info("Iniciando la actualización del archivo con ID: {}", fileChunkDTO.getId());

        // Validación mejorada para datos de archivo completos
        if (fileChunkDTO == null || fileChunkDTO.getId() == null) {
            logger.warn("ID del archivo a actualizar es nulo o datos incompletos: {}", fileChunkDTO);
            return ResponseEntity.badRequest().body(null);
        }

        try {
            FileMetadatumDTO updatedFile = fileService.updateFileMetadatum(fileChunkDTO.getId(), fileChunkDTO);
            logger.info("Archivo con ID: {} actualizado exitosamente", fileChunkDTO.getId());
            return ResponseEntity.ok(updatedFile);
        } catch (IOException e) {
            logger.error("Error al actualizar el archivo con ID: {}", fileChunkDTO.getId(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFile(@PathVariable Long id) {
        logger.info("Iniciando la eliminación del archivo con ID: {}", id);

        try {
            fileService.deleteFileMetadatum(id);
            logger.info("Archivo con ID: {} eliminado exitosamente", id);
            return ResponseEntity.ok("Archivo eliminado exitosamente.");
        } catch (Exception e) {
            logger.error("Error al eliminar el archivo con ID: {}", id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al eliminar el archivo");
        }
    }
}
