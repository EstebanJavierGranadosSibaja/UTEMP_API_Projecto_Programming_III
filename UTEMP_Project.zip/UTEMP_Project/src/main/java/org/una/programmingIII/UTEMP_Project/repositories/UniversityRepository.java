package org.una.programmingIII.UTEMP_Project.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.una.programmingIII.UTEMP_Project.models.University;

public interface UniversityRepository extends JpaRepository<University, Long> {
}
