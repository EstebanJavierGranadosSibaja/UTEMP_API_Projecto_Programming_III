package org.una.programmingIII.UTEMP_Project.services.file;

import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.una.programmingIII.UTEMP_Project.dtos.FileMetadatumDTO;
import org.una.programmingIII.UTEMP_Project.exceptions.FileNotFoundDataBaseException;
import org.una.programmingIII.UTEMP_Project.exceptions.ResourceNotFoundException;
import org.una.programmingIII.UTEMP_Project.exceptions.UserNotFoundException;
import org.una.programmingIII.UTEMP_Project.models.FileMetadatum;
import org.una.programmingIII.UTEMP_Project.models.Submission;
import org.una.programmingIII.UTEMP_Project.models.User;
import org.una.programmingIII.UTEMP_Project.repositories.FileMetadatumRepository;
import org.una.programmingIII.UTEMP_Project.repositories.SubmissionRepository;
import org.una.programmingIII.UTEMP_Project.repositories.UserRepository;

import javax.annotation.PostConstruct;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
@Transactional
public class FileServiceImplementation implements FileService {

    private static final Logger logger = LoggerFactory.getLogger(FileServiceImplementation.class);
    private final FileMetadatumRepository fileMetadatumRepository;
    private final UserRepository userRepository;
    private static final String FILE_BASE_PATH = "users/files"; // Ruta base de archivos
    private final Map<Long, List<byte[]>> fileChunksMap = new HashMap<>();
    private final SubmissionRepository submissionRepository;

    @Autowired
    public FileServiceImplementation(FileMetadatumRepository fileMetadatumRepository,
                                     SubmissionRepository submissionRepository,
                                     UserRepository userRepository) {
        this.fileMetadatumRepository = fileMetadatumRepository;
        this.userRepository = userRepository;
        this.submissionRepository = submissionRepository;
    }

    @PostConstruct
    private void initializeStoragePath() throws IOException {
        Path storagePath = Paths.get(FILE_BASE_PATH);
        if (!Files.exists(storagePath)) {
            Files.createDirectories(storagePath);
        }
    }

    @Transactional(readOnly = true)
    public Optional<FileMetadatumDTO> getFileMetadatumById(Long id) {
        return fileMetadatumRepository.findById(id)
                .map(file -> FileMetadatumDTO.builder()
                        .id(file.getId())
                        .fileName(file.getFileName())
                        .fileType(file.getFileType())
                        .fileSize(file.getFileSize())
                        .storagePath(file.getStoragePath())
                        .lastUpdate(file.getLastUpdate())
                        .createdAt(file.getCreatedAt())
                        .build());
    }

    @Override
    @Transactional
    public FileMetadatumDTO updateFileMetadatum(Long id, FileMetadatumDTO fileChunkDTO) throws IOException {
        deleteFileMetadatum(id);
        receiveFileChunk(fileChunkDTO);
        return getFileMetadatumById(id).orElse(null);
    }

    public void receiveFileChunk(FileMetadatumDTO fileChunkDTO) throws IOException {
        Long fileId = Optional.ofNullable(fileChunkDTO.getId()).orElseGet(() -> createNewFileMetadata(fileChunkDTO));
        fileChunksMap.computeIfAbsent(fileId, k -> new ArrayList<>()).add(fileChunkDTO.getFileChunk());
        validateChunkIndex(fileChunkDTO, fileChunksMap.get(fileId).size() - 1);

        if (fileChunksMap.get(fileId).size() == fileChunkDTO.getTotalChunks()) {
            finalizeFileUpload(fileId, fileChunkDTO);
        }
    }

    @Override
    @Transactional
    public void deleteFileMetadatum(Long id) {
        fileMetadatumRepository.findById(id).ifPresent(fileMetadatum -> {
            File file = new File(fileMetadatum.getStoragePath());
            if (file.exists() && !file.delete()) {
                logger.warn("No se pudo eliminar el archivo: {}", file.getAbsolutePath());
            }
            fileMetadatumRepository.deleteById(id);
        });
    }

    @Override
    public List<FileMetadatumDTO> downloadFileInChunks(Long fileId) throws IOException {
        List<FileMetadatumDTO> chunks = new ArrayList<>();
        FileMetadatum fileMetadatum = fileMetadatumRepository.findById(fileId)
                .orElseThrow(() -> new FileNotFoundDataBaseException("Archivo con ID " + fileId + " no encontrado"));

        int chunkSize = 1024 * 1024;
        byte[] buffer = new byte[chunkSize];
        try (InputStream inputStream = new FileInputStream(fileMetadatum.getStoragePath())) {
            int bytesRead, chunkIndex = 0;
            int totalChunks = (int) Math.ceil((double) fileMetadatum.getFileSize() / chunkSize);

            while ((bytesRead = inputStream.read(buffer)) > 0) {
                chunks.add(FileMetadatumDTO.builder()
                        .id(fileId)
                        .fileChunk(Arrays.copyOf(buffer, bytesRead))
                        .chunkIndex(chunkIndex++)
                        .totalChunks(totalChunks)
                        .fileName(fileMetadatum.getFileName())
                        .fileType(fileMetadatum.getFileType())
                        .build());
            }
        }
        return chunks;
    }

    private Long createNewFileMetadata(FileMetadatumDTO fileDTO) {
        User user = userRepository.findById(fileDTO.getStudent().getId())
                .orElseThrow(() -> new UserNotFoundException("Usuario con ID " + fileDTO.getStudent().getId() + " no encontrado"));

        Submission submission = submissionRepository.findById(fileDTO.getSubmission().getId())
                .orElseThrow(() -> new UserNotFoundException("Submission con ID " + fileDTO.getSubmission().getId() + " no encontrado"));

        FileMetadatum newFile = FileMetadatum.builder()
                .submission(submission)
                .student(user)
                .fileName(Optional.ofNullable(fileDTO.getFileName()).orElse("desconocido"))
                .fileType(Optional.ofNullable(fileDTO.getFileType()).orElse("desconocido"))
                .fileSize(0L)
                .storagePath(generateTempStoragePath())
                .build();

        return fileMetadatumRepository.save(newFile).getId();
    }

    private void validateChunkIndex(FileMetadatumDTO fileChunkDTO, int currentIndex) {
        if (fileChunkDTO.getChunkIndex() != currentIndex) {
            throw new IllegalArgumentException("Desajuste en índice de fragmento: se esperaba " + currentIndex + ", se obtuvo " + fileChunkDTO.getChunkIndex());
        }
    }

    private String generateTempStoragePath() {
        return FILE_BASE_PATH + "/temp_" + UUID.randomUUID();
    }

    private void finalizeFileUpload(Long fileId, FileMetadatumDTO fileChunkDTO) throws IOException {
        List<byte[]> chunks = Optional.ofNullable(fileChunksMap.get(fileId))
                .orElseThrow(() -> new FileUploadException("No se encontraron fragmentos para el archivo ID: " + fileId));

        String finalFilePath = String.format("%s/%s(%d).%s", FILE_BASE_PATH,
                fileChunkDTO.getFileName(), fileId, fileChunkDTO.getFileType());

        try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(finalFilePath))) {
            for (byte[] chunk : chunks) {
                bos.write(chunk);
            }
        }

        FileMetadatum fileMetadatum = fileMetadatumRepository.findById(fileId)
                .orElseThrow(() -> new FileNotFoundDataBaseException("Archivo con ID " + fileId + " no encontrado"));

        long totalSize = chunks.stream().mapToLong(chunk -> chunk.length).sum();
        fileMetadatum.setFileSize(totalSize);
        fileMetadatum.setStoragePath(finalFilePath);

        fileMetadatumRepository.save(fileMetadatum);
        fileChunksMap.remove(fileId);
    }
}

// private <T> T getEntityById(Long id, JpaRepository<T, Long> repository, String entityName) {
//        return findEntityById(id, repository)
//                .orElseThrow(() -> new ResourceNotFoundException(entityName, id));
//    }
//
//    private <T> Optional<T> findEntityById(Long id, JpaRepository<T, Long> repository) {
//        return repository.findById(id);
//    }