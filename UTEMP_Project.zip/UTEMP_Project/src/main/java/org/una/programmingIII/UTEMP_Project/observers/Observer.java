package org.una.programmingIII.UTEMP_Project.observers;

public interface Observer {
    void update(String eventType, String message, String mail);
}
