package org.una.programmingIII.UTEMP_Project.exceptions;

public class FileNotFoundDataBaseException extends RuntimeException {
    public FileNotFoundDataBaseException(String message) {
        super(message);
    }
}