package org.una.programmingIII.UTEMP_Project.services.autoReview;

public interface AutoReviewService {
    void autoReviewSubmission(Long submissionId);
}
