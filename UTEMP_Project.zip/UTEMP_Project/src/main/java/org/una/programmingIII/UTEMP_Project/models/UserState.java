package org.una.programmingIII.UTEMP_Project.models;

public enum UserState {
    ACTIVE,
    INACTIVE,
    SUSPENDED,
    DEPRECATED
}