package org.una.programmingIII.UTEMP_Project.models;

public interface Identifiable {
    Long getId();
}
