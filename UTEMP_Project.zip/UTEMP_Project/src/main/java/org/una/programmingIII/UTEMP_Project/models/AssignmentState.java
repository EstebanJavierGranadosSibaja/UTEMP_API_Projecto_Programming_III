package org.una.programmingIII.UTEMP_Project.models;

public enum AssignmentState {
    PENDING,
    ONGOING,
    COMPLETED,
    CANCELLED
}