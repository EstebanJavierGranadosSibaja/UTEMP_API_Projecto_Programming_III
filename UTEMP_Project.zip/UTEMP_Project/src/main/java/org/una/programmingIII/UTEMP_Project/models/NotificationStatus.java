package org.una.programmingIII.UTEMP_Project.models;

public enum NotificationStatus {
    UNREAD,
    READ
}
