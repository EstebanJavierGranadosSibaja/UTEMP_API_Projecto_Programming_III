package org.una.programmingIII.UTEMP_Project.controllers;

import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.una.programmingIII.UTEMP_Project.dtos.FileMetadatumDTO;
import org.una.programmingIII.UTEMP_Project.dtos.GradeDTO;
import org.una.programmingIII.UTEMP_Project.dtos.SubmissionDTO;
import org.una.programmingIII.UTEMP_Project.exceptions.InvalidDataException;
import org.una.programmingIII.UTEMP_Project.exceptions.ResourceNotFoundException;
import org.una.programmingIII.UTEMP_Project.models.Grade;
import org.una.programmingIII.UTEMP_Project.services.submission.SubmissionService;
import org.una.programmingIII.UTEMP_Project.utils.PageConverter;
import org.una.programmingIII.UTEMP_Project.utils.PageDTO;

import java.util.Optional;

@RestController
@RequestMapping("/utemp/submissions")
public class SubmissionController {

    private final SubmissionService submissionService;
    private final Logger logger = LoggerFactory.getLogger(SubmissionController.class);

    @Autowired
    public SubmissionController(SubmissionService submissionService) {
        this.submissionService = submissionService;
    }


    @GetMapping
    @PreAuthorize("hasAuthority('MANAGE_SUBMISSIONS')")
    public ResponseEntity<PageDTO<SubmissionDTO>> getAllSubmissions(Pageable pageable) {
        try {
            Page<SubmissionDTO> submissionsPage = submissionService.getAllSubmissions(pageable);
            PageDTO<SubmissionDTO> submissionsDTOPage = PageConverter.convertPageToDTO(submissionsPage, submissionDTO -> submissionDTO);
            return ResponseEntity.ok(submissionsDTOPage);
        } catch (Exception e) {
            logger.error("Error retrieving submissions", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('MANAGE_SUBMISSIONS')")
    public ResponseEntity<SubmissionDTO> getSubmissionById(
            @Parameter(description = "ID of the submission to retrieve", required = true) @PathVariable Long id) {
        try {
            Optional<SubmissionDTO> submissionDTO = submissionService.getSubmissionById(id);
            return submissionDTO.map(ResponseEntity::ok)
                    .orElseGet(() -> {
                        logger.warn("1Submission not found with id: {}", id);
                        return ResponseEntity.notFound().build();
                    });
        } catch (Exception e) {
            logger.error("Error retrieving submission with id: {}", id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping
    @PreAuthorize("hasAuthority('MANAGE_SUBMISSIONS')")
    public ResponseEntity<SubmissionDTO> createSubmission(
            @Valid @RequestBody SubmissionDTO submissionDTO) {
        try {
            SubmissionDTO createdSubmission = submissionService.createSubmission(submissionDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdSubmission);
        } catch (InvalidDataException e) {
            logger.warn("Invalid data for submission creation: {}", submissionDTO, e);
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            logger.error("Error creating submission", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('MANAGE_SUBMISSIONS')")
    public ResponseEntity<SubmissionDTO> updateSubmission(
            @Parameter(description = "ID of the submission to update", required = true) @PathVariable Long id,
            @Valid @RequestBody SubmissionDTO submissionDTO) {
        try {
            Optional<SubmissionDTO> updatedSubmission = submissionService.updateSubmission(id, submissionDTO);
            return updatedSubmission.map(ResponseEntity::ok)
                    .orElseGet(() -> {
                        logger.warn("Submission not found with id: {}", id);
                        return ResponseEntity.notFound().build();
                    });
        } catch (InvalidDataException e) {
            logger.warn("Invalid data for submission update: {}", submissionDTO, e);
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            logger.error("Error updating submission with id: {}", id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('MANAGE_SUBMISSIONS')")
    public ResponseEntity<Void> deleteSubmission(
            @Parameter(description = "ID of the submission to delete", required = true) @PathVariable Long id) {
        try {
            submissionService.deleteSubmission(id);
            return ResponseEntity.noContent().build();
        } catch (ResourceNotFoundException e) {
            logger.warn("Submission not found with id: {}", id, e);
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            logger.error("Error deleting submission with id: {}", id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/assignment/{assignmentId}")
    @PreAuthorize("hasAuthority('GET_ASSIGNMENT_SUBMISSIONS')")
    public ResponseEntity<PageDTO<SubmissionDTO>> getSubmissionsByAssignmentId(
            @Parameter(description = "ID of the assignment", required = true) @PathVariable Long assignmentId,
            Pageable pageable) {
        try {
            Page<SubmissionDTO> submissionsPage = submissionService.getSubmissionsByAssignmentId(assignmentId, pageable);
            PageDTO<SubmissionDTO> submissionsDTOPage = PageConverter.convertPageToDTO(submissionsPage, submissionDTO -> submissionDTO);
            return ResponseEntity.ok(submissionsDTOPage);
        } catch (Exception e) {
            logger.error("Error retrieving submissions for assignment id: {}", assignmentId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/{submissionId}/file-metadata")
    @PreAuthorize("hasAuthority('ADD_SUBMISSION_FILES')")
    public ResponseEntity<FileMetadatumDTO> addFileMetadatumToSubmission(
            @Parameter(description = "ID of the submission", required = true) @PathVariable Long submissionId,
            @Valid @RequestBody FileMetadatumDTO fileMetadatumDTO) {
        try {
            FileMetadatumDTO createdFileMetadatum = submissionService.addFileMetadatumToSubmission(submissionId, fileMetadatumDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdFileMetadatum);
        } catch (InvalidDataException e) {
            logger.warn("Invalid data for adding file metadata to submission id: {}", submissionId, e);
            return ResponseEntity.badRequest().build();
        } catch (ResourceNotFoundException e) {
            logger.warn("Submission not found with id: {}", submissionId, e);
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            logger.error("Error adding file metadata to submission id: {}", submissionId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }


    @PostMapping("/{submissionId}/grades")
    @PreAuthorize("hasAuthority('ADD_SUBMISSION_GRADES')")
    public ResponseEntity<GradeDTO> addGradeToSubmission(
            @Parameter(description = "ID of the submission", required = true) @PathVariable Long submissionId,
            @Valid @RequestBody GradeDTO gradeDTO) {
        try {
            GradeDTO createdGrade = submissionService.addGradeToSubmission(submissionId, gradeDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdGrade);
        } catch (InvalidDataException e) {
            logger.warn("Invalid data for adding grade to submission id: {}", submissionId, e);
            return ResponseEntity.badRequest().build();
        } catch (ResourceNotFoundException e) {
            logger.warn("Submission not found with id: {}", submissionId, e);
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            logger.error("Error adding grade to submission id: {}", submissionId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{submissionId}/file-metadata/{fileMetadatumId}")
    @PreAuthorize("hasAuthority('REMOVE_SUBMISSION_FILES')")
    public ResponseEntity<Void> removeFileMetadatumFromSubmission(@PathVariable Long submissionId,
                                                                  @PathVariable Long fileMetadatumId) {
        try {
            submissionService.removeFileMetadatumFromSubmission(submissionId, fileMetadatumId);
            return ResponseEntity.noContent().build();
        } catch (ResourceNotFoundException e) {
            logger.warn("Failed to remove file metadata ID {} from submission ID {}: {}", fileMetadatumId, submissionId, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        } catch (Exception e) {
            logger.error("Error removing file metadata ID {} from submission ID {}: {}", fileMetadatumId, submissionId, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }


    @DeleteMapping("/{submissionId}/grades/{gradeId}")
    @PreAuthorize("hasAuthority('REMOVE_SUBMISSION_GRADES')")
    public ResponseEntity<Void> removeGradeFromSubmission(@PathVariable Long submissionId,
                                                          @PathVariable Long gradeId) {
        try {
            submissionService.removeGradeFromSubmission(submissionId, gradeId);
            return ResponseEntity.noContent().build(); // 204 No Content response on successful removal
        } catch (ResourceNotFoundException e) {
            logger.warn("Failed to remove grade ID {} from submission ID {}: {}", gradeId, submissionId, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        } catch (Exception e) {
            logger.error("Error removing grade ID {} from submission ID {}: {}", gradeId, submissionId, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PutMapping("/{submissionId}/{gradeValue}")
    @PreAuthorize("hasAuthority('EVALUATE_SUBMISSIONS')")
    public ResponseEntity<Void> manualReviewSubmission(@PathVariable Long submissionId, @PathVariable Double gradeValue, @RequestBody String comments) {
        Optional<Grade> grade = submissionService.manualReviewSubmission(submissionId, gradeValue, comments);
        if (grade.isPresent()) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
}