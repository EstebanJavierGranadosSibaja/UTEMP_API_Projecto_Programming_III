package org.una.programmingIII.UTEMP_Project.models;

public enum SubmissionState {
    SUBMITTED,
    GRADED,
    REVISED,
    RESUBMITTED
}
