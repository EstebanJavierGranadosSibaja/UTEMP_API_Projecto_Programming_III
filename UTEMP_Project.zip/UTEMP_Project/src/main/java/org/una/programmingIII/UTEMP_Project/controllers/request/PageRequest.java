package org.una.programmingIII.UTEMP_Project.controllers.request;

public class PageRequest {
}
