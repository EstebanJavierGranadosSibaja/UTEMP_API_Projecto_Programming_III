package org.una.programmingIII.UTEMP_Project.models;

public enum CourseState {
    ACTIVE,
    INACTIVE,
    ARCHIVED
}