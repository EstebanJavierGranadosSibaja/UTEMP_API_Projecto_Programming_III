package org.una.programmingIII.UTEMP_Project.models;

public enum GradeState {
    PENDING_REVIEW,
    FINALIZED
}